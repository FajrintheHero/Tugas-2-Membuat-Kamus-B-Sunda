package com.example.kamusindo_sunda;
import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class showKamus extends Activity {

    private SQLiteDatabase db = null;
    private Cursor kamusCursor = null;
    private EditText txtIndonesia;
    private EditText txtSunda;
    private DataKamus datakamus = null;
    public static final String INDONESIA = "indonesia";
    public static final String SUNDA = "sunda";

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        datakamus = new DataKamus(this);
        db = datakamus.getWritableDatabase();
        datakamus.createTable(db);
        datakamus.generateData(db);

        setContentView(R.layout.activity_main);
        txtIndonesia = (EditText) findViewById(R.id.txtIndonesia);
        txtSunda = (EditText) findViewById(R.id.txtSunda);

    }

    public void getTerjemahan(View view) {
        String result = "";
        String indoword = txtIndonesia.getText().toString();
        kamusCursor = db.rawQuery("SELECT ID, INDONESIA, SUNDA "
                + "FROM kamus where SUNDA=" + indoword
                + " ORDER BY INDONESIA", null);

        if (kamusCursor.moveToFirst()) {
            result = kamusCursor.getString(2);
            for (; !kamusCursor.isAfterLast(); kamusCursor.moveToNext()) {
                result = kamusCursor.getString(2);
            }
        }
        if (result.equals("")) {
            result = "Terjemahan Not Found";
        }
        txtIndonesia.setText(result);

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        kamusCursor.close();
        db.close();
    }
}